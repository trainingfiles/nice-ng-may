import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component'; 
import { HeaderComp } from './header.component';
import { FooterComp } from './footer.component';
import { MainComp } from './main.component';
import { ArticleComp } from './article.component';

@NgModule({
  /* where we declare components, pipes and directives of this application */
  declarations: [ AppComponent, HeaderComp, FooterComp, MainComp, ArticleComp ],
  /* where we list the imported modules of this application */
  imports: [ BrowserModule ],
  /* where we inject the services to be used by the application */
  providers: [],
  /* where we bootstrap the default component of the application */
  bootstrap: [ AppComponent ]
})
export class AppModule { }
