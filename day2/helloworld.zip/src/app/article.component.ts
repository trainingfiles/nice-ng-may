import { Component } from "@angular/core";

@Component({
    selector : "app-article",
    template : `
    <div style="background-color: grey; color: beige; padding: 10px; margin: 5px; border: 2px solid darkolivegreen;">
        <p>
            Lorem ipsum, dolor sit amet consectetur adipisicing elit. Perspiciatis, nihil esse! Aliquid a vero corporis quo. Minima vero blanditiis ipsa iure provident! Odio excepturi sint voluptate quidem dolores, eius maxime!
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Perferendis aliquid, minima dignissimos aspernatur rem vel dolores numquam itaque tempora quaerat assumenda similique consequuntur vero. Impedit illum ut cumque inventore ad?
            Lorem ipsum dolor sit amet consectetur adipisicing elit. Nemo minima labore impedit ab at, magnam aspernatur tempora. Veniam reiciendis laudantium ad consectetur, saepe eaque nostrum doloremque eum aliquam sit alias.
        </p>
    </div>
    `
})
export class ArticleComp{

}