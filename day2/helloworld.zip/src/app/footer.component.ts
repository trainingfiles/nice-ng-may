import { Component } from "@angular/core";

@Component({
    selector : "app-footer",
    template : `
    <div style="height: 50px; background-color: darkolivegreen; color: beige;">
        <h3 style="margin: 0px; line-height: 50px; padding-left: 10px;">&copy; Copyrights reserved by Nice Pune</h3>
    </div>
    `
})
export class FooterComp{

}