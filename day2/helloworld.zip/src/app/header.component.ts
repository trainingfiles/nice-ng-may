import { Component } from "@angular/core";

@Component({
    selector : "app-header",
    template : `
    <div style="height: 100px; background-color: darkolivegreen; color: beige;">
        <h2 style="margin: 0px; text-align: center; line-height: 100px;">Nice Pune Header Component</h2>
    </div>
    `
})
export class HeaderComp{

}