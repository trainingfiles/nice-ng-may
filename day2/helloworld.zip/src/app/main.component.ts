import { Component } from "@angular/core";

@Component({
    selector : "app-main",
    template : `
    <div style="background-color: darkkhaki; color: beige; padding: 10px;">
       <app-article></app-article>
       <app-article></app-article>
    </div>
    `
})
export class MainComp{

}