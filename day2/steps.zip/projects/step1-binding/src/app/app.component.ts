import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <h1>Binding in Angular</h1> 
    <hr>
    <h2>{{ title }}</h2>   
    <h2>{{ title.toUpperCase() }}</h2>   
    <h2>{{ title.length }}</h2>   
    <h2>{{ title.length * 2 }}</h2>   
    <hr>
    <h3 [innerHTML]="title"></h3>
    <h3 [textContent]="title"></h3>
    <h3 [innerText]="title"></h3>
    <h4 innerHTML="{{ title }}"></h4>
    <h5 bind-innerHTML="title"></h5>
    <hr>
    <input type="checkbox" [checked]="show">
    <br>
    <button [disabled]="show">Enable / Disable Me</button>
    <br>
    <input type="text" [value]="title">
    <hr>
    <button (click)="clickHandler()">Click Me</button>
    <button (click)="show = !show">Show / Hide</button>
    <!-- <input [value]="title" #ti (input)="title = ti.value" type="text"> -->
    <input [(ngModel)]="title">
    <hr>
    <h3>Power : {{ power }}</h3>
    <button (click)="increasePower()">Increase Power</button>
    <input #pow [value]="power" (input)="power = pow.value" type="number">
  `,
  styles: []
})
export class AppComponent {
  title = 'Nice Pune Application';
  show = true;
  power:any = 0;
  clickHandler(){
    alert("hello there")
  }
  increasePower(){
    this.power = Number(this.power) + 1;
  }
}
