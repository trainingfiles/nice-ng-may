import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div>
      <h1> Directives in Angular </h1>
      <button (click)="show = !show">Toggle</button>
      <h2 [hidden]="!show">1st h2 tag {{ title }}</h2>
      <h2 *ngIf="show">2nd h2 tag {{ title }}</h2>
      <!-- <span *ngIf="show">{{ title }}</span> -->
      <ng-template [ngIf]="show">{{ title }}</ng-template>
      <ol>
        <li>{{ avengers[0] }}</li>
        <li>{{ avengers[1] }}</li>
        <li>{{ avengers[2] }}</li>
      </ol>
      <ul>
        <li *ngFor="let hero of avengers; index as idx; first as fst; last as lst; odd as od; even as ev">
          <span *ngIf="od"> | Odd Avenger</span>
          <span *ngIf="ev"> | Even Avenger</span>
          <span *ngIf="fst"> | First Avenger</span>
          <span *ngIf="lst"> | Last Avenger</span>
          <span *ngIf="!lst && !fst"> | Inbetween Avenger</span>
          {{ idx +" > "+ hero }}
        </li>
      </ul>
      <ng-template ngFor let-hero [ngForOf]="avengers" > {{ hero }} </ng-template>
      <hr>
      <input #scoreInput min="0" max="5" [value]="score" (input)="score = scoreInput.value" type="number">
      <ol [ngSwitch]="score">
        <li *ngSwitchCase="1" >*</li>
        <li *ngSwitchCase="2" >**</li>
        <li *ngSwitchCase="3" >***</li>
        <li *ngSwitchCase="4" >****</li>
        <li *ngSwitchCase="5" >*****</li>
        <li *ngSwitchDefault>no stars yet</li>
      </ol>
      <h2 ngNonBindable>{{ hello nice pune }}</h2>
      <h3 style="width:200px; height:100px; background-color: darkred; color: papayawhip; text-align: center; margin: 0px; line-height: 50px;">box</h3>
        <br>
      <h3 [style.color]="'orange'">player</h3>
      <h3 [ngStyle]="{'color': score > 4  ?  'green'  :  'red'}">player</h3>
    </div>
  
  `,
  styles: []
})
export class AppComponent {
  title = 'welcome to your life';
  show = true;
  inlinestyle = "width:200px; height:100px; background-color: darkred; color: papayawhip; text-align: center; margin: 0px; line-height: 50px;"
  avengers = ['Ironman','Hulk','Thor','Spiderman','Black Widow', 'Scarlet', 'Captain Marvel', "Hawkeye"];
  score:any = 3;
  showredbox = true;
  showgreenbox = true;
}
