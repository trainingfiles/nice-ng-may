import { Pipe } from "@angular/core";

@Pipe({
    name : "gen"
})
export class GenPipe{
    transform(...args:any) {
        // return label+" "+message;
        return args[1] == 'male' ? "Mr "+args[0]+" is from "+args[2] : "Miss "+args[0]+" is from "+args[2]
    }
}