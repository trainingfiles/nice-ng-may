import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <h1>Component Communication</h1>
  <h1>Child message comes here {{ message }}</h1>
  <hr>
  <h2>Component Content Projection</h2>
  <input #ti [value]="title" (input)="title = ti.value" type="text">
  <app-child (childEvent)="childEventHanlder($event)"  [cl]="title">
    <ul>
      <li>List Item 1</li>
      <li>List Item 2</li>
      <li class="box">List Item 3</li>
      <li>List Item 4</li>
      <li>List Item 5</li>
    </ul>
    <button>Click me</button>
    <h3> Nice Pune Banner </h3>
    <p>
      Lorem ipsum, dolor sit amet consectetur adipisicing elit. Explicabo animi sint architecto accusantium. Eaque maxime, temporibus officiis odit eius, alias inventore a, delectus ullam quia iure cupiditate illo veritatis aut!
    </p>
    <p class="x">
      paragraph with class 
      <br>
      Lorem ipsum dolor sit amet consectetur, adipisicing elit. In molestiae dignissimos eveniet, molestias eos quas dolore nam repudiandae ducimus omnis, obcaecati, sint nesciunt dolorum tenetur ex pariatur aut deleniti minima.
    </p>
    {{ title }}
  </app-child>
  `,
  styles: []
})
export class AppComponent {
  title = 'step2-communication';
  message = 'default message';
  childEventHanlder(message:any){
    // alert(message);
    this.message = message;
  }
}
