import { Component, EventEmitter, Input, Output } from '@angular/core';

@Component({
  selector: 'app-child',
 /*  inputs : ['label'], */
  template: `
   <div>
    <h2>Child Component</h2>
    <div style="border: 1px solid grey; padding : 10px; margin : 10px">
      <!-- <ng-content></ng-content> -->
      <ng-content select="h3"></ng-content>
      <ng-content select="ul"></ng-content>
      <ng-content select="button"></ng-content>
      <ng-content select=".x"></ng-content>
      <ng-content></ng-content>
    </div>
    <hr>
    <h3>{{ label }}</h3>
    <input #msg type="text">
    <button (click)="buttonclickhandler(msg.value)">Click Me</button>
   </div>
  `,
  styles: [
  ]
})
export class ChildComponent {
 @Input('cl') label:any = "child label";
 // label:any = "child label";
 @Output() childEvent:EventEmitter<any> = new EventEmitter();

 buttonclickhandler(msg:any){
    this.childEvent.emit(msg);
 }
}
