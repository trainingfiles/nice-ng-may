import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-grid',
  template: `
    <table class="table table-striped table-hover">
    <thead class="table-dark">
      <tr>
        <th>Sl#</th>
        <th>Title</th>
        <th>Name</th>
        <th>Poster</th>
        <th>City</th>
        <th>Ticket Price</th>
        <th>Release Date</th>
        <th>Movies</th>
      </tr>
    </thead>
    <tbody>
      <tr *ngFor="let hero of data">
        <td>{{ hero.sl }}</td>
        <td>{{ hero.title | uppercase }}</td>
        <td>{{ hero.firstname+' '+hero.lastname }}</td>
        <td>
          <img [src]="hero.poster" [alt]="hero.title" width="60">
        </td>
        <td>{{ hero.city }}</td>
        <td>{{ hero.ticketprice | currency : 'INR' : 'symbol' : '4.2-3' }} </td>
        <td>{{ hero.releasedate | date : 'dd-MMMM-yyyy' }} </td>
        <td>
          <button class="btn btn-primary">{{ hero.movieslist.length }}</button>
        </td>
      </tr>
    </tbody>
  </table>
  `,
  styles: [
  ]
})
export class GridComponent {
 @Input() data:any = []
}
