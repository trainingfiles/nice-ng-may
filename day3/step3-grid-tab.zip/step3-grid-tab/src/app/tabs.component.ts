import { Component, Input } from '@angular/core';

@Component({
  selector: 'app-tabs',
  template: `
     <ul class="nav justify-content-center">
        <li  class="nav-item" *ngFor="let hero of data"> <a  class="nav-link" href="#">{{ hero.title }}</a> </li>
     </ul>
  `,
  styles: [
  ]
})
export class TabsComponent {
  @Input() data:any = []
}
