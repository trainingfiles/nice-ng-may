import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
  <div class="container">
  <h1> Service in Angular </h1>
  <app-tabs></app-tabs>
  <hr>
  <app-grid></app-grid>
  </div>
  `,
  styles: []
})
export class AppComponent {
  title = 'step3-grid-tab';
  heroes:any = [];
  /* 
  hs:HeroService = new HeroService();
  constructor(){
    this.heroes = this.hs.getData();
  } 
  */

 /*   
 constructor( private hs:HeroService ){
    this.heroes = this.hs.getData();
  }  
 */
}
