import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { GridComponent } from './grid.component';
import { TabsComponent } from './tabs.component';
import { HeroService } from './hero.service';

@NgModule({
  declarations: [
    AppComponent,
    GridComponent,
    TabsComponent
  ],
  imports: [
    BrowserModule
  ],
  providers: [ HeroService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
