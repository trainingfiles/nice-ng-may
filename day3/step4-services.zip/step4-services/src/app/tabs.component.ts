import { Component, Input } from '@angular/core';
import { HeroService } from './hero.service';

@Component({
  selector: 'app-tabs',
  template: `
  <h3>Version : {{ version }}</h3>
     <ul class="nav justify-content-center">
        <li  class="nav-item" *ngFor="let hero of data"> <a  class="nav-link" href="#">{{ hero.title }}</a> </li>
     </ul>

  `,
  styles: [
  ]
})
export class TabsComponent {
  data:any = [];
  version = 0;
  constructor(private hs:HeroService){
    this.data = this.hs.getData();
    this.version = this.hs.getVersion();
  }
}
