import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <div style="text-align:center">
      <h1> Custom Component, Pipe, Directive, Module </h1>
    </div>
    <p nice="red">
      Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusamus esse quibusdam ut impedit praesentium laudantium provident maxime! A ipsum maxime dignissimos sequi architecto iste explicabo vero molestiae atque at! A?
    </p>
    <p nice="orange">
      Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusamus esse quibusdam ut impedit praesentium laudantium provident maxime! A ipsum maxime dignissimos sequi architecto iste explicabo vero molestiae atque at! A?
    </p>
    <p nice="yellow">
      Lorem, ipsum dolor sit amet consectetur adipisicing elit. Accusamus esse quibusdam ut impedit praesentium laudantium provident maxime! A ipsum maxime dignissimos sequi architecto iste explicabo vero molestiae atque at! A?
    </p>
    <ul>
      <li>{{ 'Batman' | gen : 'male' : 'Gotham'}}</li>
      <li>{{ 'Ironman' | gen : 'male' : 'New York'}}</li>
      <li>{{ 'Phantom' | gen : 'male' : 'Bangala'}}</li>
      <li>{{ 'Wonder Women' | gen : 'female' : 'Amazona'}}</li>
    </ul>

    <app-nice></app-nice>
    <app-nice></app-nice>
    <app-nice></app-nice>
  `,
  styles: []
})
export class AppComponent {
  title = 'step5-custom';
}
