import { Component } from "@angular/core";

@Component({
    selector : "app-nice",
    template : `
        <div class="box" [style.backgroundColor]="selectedcolor">
            <input #ic type="color" (change)="selectedcolor = ic.value">
        </div>
    `,
    styles : [`
        .box{
            width : 200px;
            height : 100px;
            border : 1px solid silver;
            margin : 10px    
        }
    `]
    
})
export class NiceComp{
    selectedcolor:any;

}