import { Directive, ElementRef, Input, OnInit } from "@angular/core";

/*
tag / element    : 'nice'
class            : '.nice'
attribute        : '[nice]'
*/

@Directive({
    selector : '[nice]'
})
export class NiceDirective implements OnInit{
    @Input() nice:string = "";
    constructor(private elRef:ElementRef){}
    ngOnInit(){
       /* 
       let tempInnerHTMl = this.elRef.nativeElement.innerHTML;
       let elm =  document.createElement("div");
           elm.setAttribute("style","background-color: red");
           elm.innerHTML = tempInnerHTMl;
        this.elRef.nativeElement.innerHTML = elm; 
        */
       // this.elRef.nativeElement.style.backgroundColor = this.nice;
       this.elRef.nativeElement.addEventListener("click", this.clickHandler);

    }

    clickHandler(event:any){
        // alert("you clicked the content");
        // this.elRef.nativeElement.addEventListener("click", this.clickHandler);
        // console.log(event);
        // event.target.style.backgroundColor = this.nice;
        // event.target.innerHTML = "You Clicked Me";
        event.target.setAttribute("style","background-color : "+event.target.getAttribute("nice"));
    }
}