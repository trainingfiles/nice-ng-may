import { NgModule } from "@angular/core";
import { NiceComp } from "./nice.component";
import { NiceDirective } from "./nice.directive";
import { GenPipe } from "./gen.pipe";

@NgModule({
    declarations : [NiceComp, NiceDirective, GenPipe],
    exports : [NiceComp, NiceDirective, GenPipe]
})
export class NiceModule{

} 