import { Component, ViewChild } from '@angular/core';
import { ChildComponent } from './child.component';

@Component({
  selector: 'app-root',
  template: `
    <h1>Component Life Cycle</h1>
    <app-child *ngIf="show"></app-child>
    <button (click)="show = !show">show / hide</button>
    <button (click)="increaseChildPower()">Increase Power</button>
    <button (click)="decreaseChildPower()">Decrease Power</button>

  `,
  styles: []
})
export class AppComponent {
  title = 'step6-lifecycle';
  show = true;
  // @ViewChild("childComp") cc:ChildComponent = new ChildComponent();
  @ViewChild(ChildComponent) cc:ChildComponent = new ChildComponent();
  increaseChildPower(){
    this.cc.increasePower();
  }
  decreaseChildPower(){
    this.cc.decreasePower();
  }
  
}
