import { AfterContentChecked, AfterContentInit, AfterViewChecked, AfterViewInit, Component, DoCheck, Input, OnChanges, OnDestroy, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-child',
  template: `
    <h1>Child Component</h1>
    <h2>Power is {{ power }}</h2>
    <h2>Version is {{ version }}</h2>
  `,
  styles: [
  ]
})
export class ChildComponent implements  OnInit, 
                                        OnChanges, 
                                        OnDestroy, 
                                        AfterViewInit, 
                                        AfterViewChecked, 
                                        AfterContentInit, 
                                        AfterContentChecked, 
                                        DoCheck {
  power = 0;
  version = 0;

  constructor(){
    console.log("ChildComponent's constructor was called" )
  }
  // -------------------------------------
  increasePower(){
    this.power++;
  }
  decreasePower(){
    this.power--;
  }
  // -------------------------------------
  ngOnInit(): void {
    console.log("ChildComponent's ngOnInit was called" )
  }
  ngOnChanges(changes: SimpleChanges): void {
    console.log("ChildComponent's ngOnChanges was called" )
  }
  ngOnDestroy(): void {
    console.log("ChildComponent's ngOnDestroy was called" )
  }
  ngAfterContentChecked(): void {
    console.log("ChildComponent's ngAfterContentChecked was called" )
  }
  ngAfterContentInit(): void {
    console.log("ChildComponent's ngAfterContentInit was called" )
  }
  ngAfterViewChecked(): void {
    console.log("ChildComponent's ngAfterViewChecked was called" )
  }
  ngAfterViewInit(): void {
    console.log("ChildComponent's ngAfterViewInit was called" )
  }
  ngDoCheck(): void {
    console.log("ChildComponent's ngDoCheck was called" )
  }
}
