import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <app-usergrid/>
  `,
  styles: []
})
export class AppComponent {
  title = 'step7-ajax';
}
