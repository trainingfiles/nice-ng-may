import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { UserService } from './user.service';
import { UserGrid } from './usergrid.component';

@NgModule({
  declarations: [ AppComponent, UserGrid ],
  imports: [ BrowserModule, HttpClientModule ],
  providers: [ UserService ],
  bootstrap: [AppComponent]
})
export class AppModule { }
