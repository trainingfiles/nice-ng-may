import { Component, OnInit, OnDestroy } from "@angular/core";
import { UserService } from "./user.service";

@Component({
    selector : "app-usergrid",
    template : `
    <h2>Ajax in Angular</h2>
        <div *ngIf="userdata.length > 0">
            <ul>
                <li *ngFor="let user of userdata">{{ user.id +" : "+ user.name +" | "+user.username +" | "+ user.email }}</li>
            </ul>
        </div>
    `
})
export class UserGrid implements OnInit{
    userdata:any = [];
    constructor(private us:UserService){}
    ajax:any;
    ngOnInit(){
        this.us.getUserData().subscribe((res)=>{
            this.userdata = res;
        })
       /*  this.ajax = this.us.getUserData().subscribe((res)=>{
            this.userdata = res;
        }) */
    }
   /*  ngOnDestroy(){
        this.ajax.unsubscribe();
    } */
}