let express = require("express");
let mongoose = require("mongoose");
let config = require("./config.json");
let cors = require("cors");

let app = express();
    app.use(express.json());
    app.use(cors());

//-----------------------------------------------
let Schema = mongoose.Schema;
let ObjectId = Schema.ObjectId;
let User = mongoose.model("User", new Schema({
    id : ObjectId,
    username : String,
    userage : String,
    usercity : String,
    userphone : String
}));

/* 
let dburi = "mongodb+srv://{{dbuser}}:{{dbpass}}@{{dbcluster}}.{{dbstring}}.mongodb.net/{{dbname}}?retryWrites=true&w=majority";
let clouddb = dburi.replace("{{dbuser}}", config.dbuser)
                .replace("{{dbpass}}", config.dbpass)
                .replace("{{dbcluster}}", config.dbcluster)
                .replace("{{dbstring}}", config.dbstring)
                .replace("{{dbname}}", config.dbname) 
*/
let clouddb = "mongodb+srv://admin:7aAkt51IeXD2QnLB@vjcluster.9cjwnyo.mongodb.net/nicedb?retryWrites=true&w=majority";

// let localdb = "mongodb://127.0.0.1:27017/nicedb";
mongoose.connect(clouddb)
.then(res=>console.log("DB Connected"))
.catch(err=>console.log("Error", err));
//-----------------------------------------------
// CRUD
// CREATE
// UPDATE
// DELETE

// READ
app.get("/data", (req, res)=>{
    User.find().then(dbres => res.status(200).send(dbres))
    .catch(err => res.status(400).send({"dberror": err}))
})
// CREATE
app.post("/data", (req, res)=>{
    let user = new User(req.body);
    user.save()
    .then(dbres => res.status(200).send({message : dbres.username+" was added"}))
    .catch(error => console.log(error)); 
})

// READ BEFORE UPDATE
app.get("/user/:uid", (req, res)=>{
    // console.log("read before update request recieved")
    User.findById({_id : req.params.uid})
    .then( dbres => res.send(dbres))
    .catch( err => console.log("Error", err))
})
// UPDATE
app.put("/user/:uid", (req, res)=>{
    User.findById({_id : req.params.uid})
    .then(userToEdit => {
        userToEdit.username = req.body.username;
        userToEdit.userage = req.body.userage;
        userToEdit.usercity = req.body.usercity;
        userToEdit.userphone = req.body.userphone;
        userToEdit.save();
        res.status(200).send({"update": userToEdit.username+" was updated"})
    })
    .catch(error => console.log("Error", error))
})

// DELETE
app.delete("/delete/:uid", (req, res)=>{
    User.findByIdAndDelete({_id : req.params.uid})
    .then(dbres => res.status(200).send({ "message" :dbres.username+" was deleted"}))
    .catch( err => console.log("Error ", err))
})

app.listen(config.port,config.host, (error)=>{
    if(error){ console.log("Error ", error )}
    else{ console.log(`web server is now live on ${ config.host }:${ config.port }`) }
})