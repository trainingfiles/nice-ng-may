import { Component } from '@angular/core';
import { FormBuilder, FormGroup, FormControl, Validators } from "@angular/forms"

@Component({
  selector: 'app-reactive-form',
  template: `
  <div class="container">
    <h2>Reactive / Data Driven Form</h2>

    <form [formGroup]="userForm" name="nicetempreg" action="" method="get" >
    <div class="mb-3">
      <label class="form-label" for="uname">User Name</label>
      <input [ngClass]="{ errline : userForm.get('username').touched && userForm.get('username').invalid, validline : userForm.get('username').touched && userForm.get('username').valid  }" 
      formControlName="username" class="form-control" id="uname" name="uname" >
      <div *ngIf="userForm.get('username').touched && userForm.get('username').invalid" class="form-text err">User Name is Invalid</div>
    </div>
    
    <div class="mb-3">
      <label class="form-label" for="uage">User Age</label>
      <input [ngClass]="{ errline : userForm.get('userage').touched && userForm.get('userage').invalid, validline : userForm.get('userage').touched && userForm.get('userage').valid  }"  formControlName="userage" class="form-control" id="uage" name="uage" type="number">
      <div *ngIf="userForm.get('userage').value > 80" class="form-text err">User is too old</div>
      <div *ngIf="userForm.get('userage').value < 18 && userForm.get('userage').touched" class="form-text err">User is too young</div>
    </div>
    
    <div class="mb-3">
      <label class="form-label" for="ucity">User City</label>
      <input  [ngClass]="{ errline : userForm.get('usercity').touched && userForm.get('usercity').invalid, validline : userForm.get('usercity').touched && userForm.get('usercity').valid  }"  formControlName="usercity" class="form-control" id="ucity" name="ucity">
      <div  *ngIf="userForm.get('usercity').touched && userForm.get('usercity').invalid" class="form-text err">User City is Invalid</div>
    </div>
    
    <div class="mb-3">
      <label class="form-label" for="uphone">User Phone</label>
      <input  [ngClass]="{ errline : userForm.get('userphone').touched && userForm.get('userphone').invalid, validline : userForm.get('userphone').touched && userForm.get('userphone').valid  }"  formControlName="userphone" class="form-control" id="uphone" name="uphone">
      <div  *ngIf="userForm.get('userphone').touched && userForm.get('userphone').invalid" class="form-text err">User's Phone is Invalid</div>
    </div>

      <button class="btn btn-primary" type="submit">Register</button>
      <button class="btn btn-info" (click)="fillCity()">Fill City</button>
      <button class="btn btn-warning" (click)="fillDetails()" type="submit">Fill Form</button>
   </form>
   <hr>

   <ul>
    <li *ngIf="userForm.get('username').untouched">User Name is Untouched</li>
    <li *ngIf="userForm.get('username').touched">User Name is Touched</li>
    <li *ngIf="userForm.get('username').pristine">User Name is Prisitne</li>
    <li *ngIf="userForm.get('username').dirty">User Name is Dirty</li>
    <li *ngIf="userForm.get('username').invalid">User Name is InValid</li>
    <li *ngIf="userForm.get('username').valid">User Name is Valid</li>
   </ul>
   <ul>
    <li *ngIf="userForm.get('userage').untouched">User Age is Untouched</li>
    <li *ngIf="userForm.get('userage').touched">User Age is Touched</li>
    <li *ngIf="userForm.get('userage').pristine">User Age is Prisitne</li>
    <li *ngIf="userForm.get('userage').dirty">User Age is Dirty</li>
    <li *ngIf="userForm.get('userage').invalid">User Age is InValid</li>
    <li *ngIf="userForm.get('userage').valid">User Age is Valid</li>
   </ul>
   <ul>
    <li *ngIf="userForm.get('userphone').untouched">User Phone is Untouched</li>
    <li *ngIf="userForm.get('userphone').touched">User Phone is Touched</li>
    <li *ngIf="userForm.get('userphone').pristine">User Phone is Prisitne</li>
    <li *ngIf="userForm.get('userphone').dirty">User Phone is Dirty</li>
    <li *ngIf="userForm.get('userphone').invalid">User Phone is InValid</li>
    <li *ngIf="userForm.get('userphone').valid">User Phone is Valid</li>
   </ul>


   <ul>
    <li>User Name : {{ userForm.get('username').value }}</li>
    <li>User Age : {{ userForm.get('userage').value }}</li>
    <li>User City : {{ userForm.get('usercity').value }}</li>
    <li>User Phone : {{ userForm.get('userphone').value }}</li>
   </ul>

  </div>
    `,
  styles: [`
  .err{
    color : crimson;
  }
  .errline{
    border : 2px solid crimson;
  }
  .validline{
    border : 2px solid darkseagreen;
  }
`]
})
export class ReactiveFormComponent {
  
  userForm:any;

  constructor(private fb:FormBuilder){}

  ngOnInit(){
    this.userForm = this.fb.group({
      username : ["", Validators.required ],
      userage : ["", [Validators.required, Validators.min(18), Validators.max(80)] ],
      usercity : ["", Validators.required ],
      userphone : ["", [Validators.required, Validators.pattern('[0-9]{3}-[0-9]{8}')] ],
    })
  }

  fillCity(){
    this.userForm.patchValue({
      usercity : "Pune"
    })
  }

  fillDetails(){
    this.userForm.setValue({
      username : "Batman",
      userage : 23,
      usercity : "Pune",
      userphone : '123-12345678'
    })
  }
  
  
}
