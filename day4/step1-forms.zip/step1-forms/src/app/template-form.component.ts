import { Component } from '@angular/core';

@Component({
  selector: 'app-template-form',
  template: `
  <div class="container">
  <h2>Template Form</h2>
   <form name="nicetempreg" #myform="ngForm" (submit)="formSubmitHandler(myform, $event)" action="" method="get" >
    <div class="mb-3">
      <label class="form-label" for="uname">User Name</label>
      <input [class.errline]="username.invalid && username.touched" [class.validline]="username.touched && username.valid" #username="ngModel" [(ngModel)]="userdata.name" required class="form-control" id="uname" name="uname" type="text">
      <div *ngIf="username.invalid && username.touched" class="form-text err">User Name is Invalid</div>
    </div>
    
    <div class="mb-3">
      <label class="form-label" for="uage">User Age</label>
      <input [class.errline]="userage.invalid && userage.touched" [class.validline]="userage.touched && userage.valid"  #userage="ngModel" [(ngModel)]="userdata.age" required min="18" max="80" class="form-control" id="uage" name="uage" type="number">
      <div *ngIf="userdata.age > '80'"  class="form-text err">User is too old</div>
      <div *ngIf="userage.touched && userdata.age < '18'"  class="form-text err">User is too young</div>
    </div>
    
    <div class="mb-3">
      <label class="form-label" for="ucity">User City</label>
      <input [class.errline]="usercity.invalid && usercity.touched" [class.validline]="usercity.touched && usercity.valid"  #usercity="ngModel" [(ngModel)]="userdata.city" required class="form-control" id="ucity" name="ucity" type="text">
      <div *ngIf="usercity.invalid && usercity.touched"  class="form-text err">User City is Invalid</div>
    </div>
    
    <div class="mb-3">
      <label class="form-label" for="uphone">User Phone</label>
      <input [class.errline]="userphone.invalid && userphone.touched" [class.validline]="userphone.touched && userphone.valid"  #userphone="ngModel" [(ngModel)]="userdata.phone" required pattern="[0-9]{3}-[0-9]{8}" class="form-control" id="uphone" name="uphone" type="text">
      <div *ngIf="userphone.invalid && userphone.touched"  class="form-text err">User's Phone is Invalid</div>
    </div>

      <button class="btn btn-primary" type="submit">Register</button>
   </form>
   <hr>
   <ul>
    <li *ngIf="username.untouched">User Name is Untouched</li>
    <li *ngIf="username.touched">User Name is Touched</li>
    <li *ngIf="username.pristine">User Name is Prisitne</li>
    <li *ngIf="username.dirty">User Name is Dirty</li>
    <li *ngIf="username.invalid">User Name is InValid</li>
    <li *ngIf="username.valid">User Name is Valid</li>
   </ul>
   <ul>
    <li *ngIf="userage.untouched">User Age is Untouched</li>
    <li *ngIf="userage.touched">User Age is Touched</li>
    <li *ngIf="userage.pristine">User Age is Prisitne</li>
    <li *ngIf="userage.dirty">User Age is Dirty</li>
    <li *ngIf="userage.invalid">User Age is InValid</li>
    <li *ngIf="userage.valid">User Age is Valid</li>
   </ul>
   <ul>
    <li *ngIf="userphone.untouched">User Phone is Untouched</li>
    <li *ngIf="userphone.touched">User Phone is Touched</li>
    <li *ngIf="userphone.pristine">User Phone is Prisitne</li>
    <li *ngIf="userphone.dirty">User Phone is Dirty</li>
    <li *ngIf="userphone.invalid">User Phone is InValid</li>
    <li *ngIf="userphone.valid">User Phone is Valid</li>
   </ul>
   <ul>
    <li>User Name : {{ userdata.name }}</li>
    <li>User Age : {{ userdata.age }}</li>
    <li>User City : {{ userdata.city }}</li>
    <li>User Phone : {{ userdata.phone }}</li>
   </ul>
  </div>
  `,
  styles: [`
    .err{
      color : crimson;
    }
    .errline{
      border : 2px solid crimson;
    }
    .validline{
      border : 2px solid darkseagreen;
    }
  `]
})
export class TemplateFormComponent {
  userdata = {
    name : "",
    age : "",
    city : "",
    phone : ""
  }

  formSubmitHandler(formdata:any, event:any){
    event.preventDefault();
    // console.log(formdata.value.uage);
    console.log(event);
    if(formdata.value.uage < 18){
      alert("you are too young to join us")
    }else if(formdata.value.uage > 80){
      alert("you are too old to join us")
    }else{
      // alert("welcome to our company")
      event.target.submit();
    }
  }
}
