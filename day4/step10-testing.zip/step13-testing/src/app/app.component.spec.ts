import { AppComponent } from './app.component';

describe('AppComponent', () => {
  let app = null;

  // let users = [];

  beforeEach(() => {
    console.log("before each");
    app = new AppComponent();
  });
  
  it('should be 5', () => {
    console.log("inside test");
    expect(app.power).toBe(5);
  });
  
  it('should be created', () => {
    console.log("inside test");
    expect(app.power).toBeDefined();
  });

  it('should be less than 10', () => {
    console.log("inside test");
    expect(app.power).toBeLessThan(10);
  });


  it('should have title as batman', () => {
    console.log("inside test");
    expect(app.title).toBe('batman');
  });

  it("should incrase power by 1",()=>{
    app.increasePower();
    expect(app.power).toBe(6);
  })

  afterEach(()=>{
    console.log("After Each");
  });

  afterAll(()=>{
    app = null;
  })

});
