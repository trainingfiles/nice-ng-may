import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `

  `,
  styles: []
})
export class AppComponent {
  title = 'batman';
  power = 5;
  increasePower(){
    this.power = this.power+1;
  }
}
