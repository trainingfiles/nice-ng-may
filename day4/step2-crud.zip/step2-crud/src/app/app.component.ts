import { Component, OnInit } from '@angular/core';
import { UserService } from './user.service';
/* 
    _id : ObjectId;
    username : String,
    userage : String,
    usercity : String,
    userphone : String
*/
@Component({
  selector: 'app-root',
  template: `
    <div class="container">
      <h1>CRUD Application with MongoDB</h1>
      <hr>
      <table class="table table-striped table-hover">
        <thead>
          <tr>
            <th>Sl #</th>
            <th>User Name</th>
            <th>USer Age</th>
            <th>User City</th>
            <th>User Phone</th>
            <th>Edit</th>
            <th>Delete</th>
          </tr>
        </thead>
        <tbody>
          <tr *ngFor="let user of userlist; index as idx">
            <td>{{ idx + 1 }}</td>
            <td>{{ user.username }}</td>
            <td>{{ user.userage }}</td>
            <td>{{ user.usercity }}</td>
            <td>{{ user.userphone }}</td>
            <td><button (click)="editUserInfo(user._id)" class="btn btn-warning"> Edit </button></td>
            <td><button (click)="deleteUserInfo(user._id)" class="btn btn-danger"> Delete </button></td>
          </tr>
        </tbody>
      </table>

      <div *ngIf="show">
          <h2>Add User Info</h2>
          <div class="mb-3">
            <label for="uname" class="form-label">User Name</label>
            <input [(ngModel)]="nuser.username" class="form-control" id="uname">
          </div>
          <div class="mb-3">
            <label for="uage" class="form-label">User Age</label>
            <input [(ngModel)]="nuser.userage" class="form-control" id="uage">
          </div>
          <div class="mb-3">
            <label for="ucity" class="form-label">User City</label>
            <input [(ngModel)]="nuser.usercity" class="form-control" id="ucity">
          </div>
          <div class="mb-3">
            <label for="uphone" class="form-label">User Phone</label>
            <input [(ngModel)]="nuser.userphone" class="form-control" id="uphone">
          </div>
          <div class="col-auto">
            <button (click)="addHandler()" class="btn btn-primary mb-3">Add User Info</button>
          </div>
      </div>

      <div *ngIf="!show">
          <h2>Edit User Info</h2>
          <div class="mb-3">
            <label for="euname" class="form-label">Edit User Name</label>
            <input [(ngModel)]="euser.username" class="form-control" id="euname">
          </div>
          <div class="mb-3">
            <label for="euage" class="form-label">Edit User Age</label>
            <input [(ngModel)]="euser.userage" class="form-control" id="euage">
          </div>
          <div class="mb-3">
            <label for="eucity" class="form-label">Edit User City</label>
            <input [(ngModel)]="euser.usercity" class="form-control" id="eucity">
          </div>
          <div class="mb-3">
            <label for="euphone" class="form-label">Edit User Phone</label>
            <input [(ngModel)]="euser.userphone" class="form-control" id="euphone">
          </div>
          <div class="col-auto">
            <button (click)="updateHandler()" class="btn btn-primary mb-3">Update User Info</button>
          </div>
      </div>
    </div>
  `,
  styles: []
})
// export class AppComponent implements OnInit {
export class AppComponent{
  title = 'step2-crud';
  show = true;
  nuser = {
    username : "",
    userage : "",
    usercity : "",
    userphone : ""
  }
  euser:any = {
    _id : "",
    username : "",
    userage : "",
    usercity : "",
    userphone : ""
  }
  userlist:any = []; 
  constructor(private us:UserService){
    // empty
  }

  refresh(){
    this.us.getUserData().subscribe( res => this.userlist = res);
  }

  ngOnInit(){
    this.refresh();
  }

  addHandler(){
    this.us.postUserData(this.nuser).subscribe( res => {
      this.refresh();
      this.nuser = {
        username : "",
        userage : "",
        usercity : "",
        userphone : ""
      }
      console.log(res);
    } );
  }

  updateHandler(){
    // update 
    this.us.postUserAfterUpdate(this.euser).subscribe( res => {
      console.log(res);
      this.refresh();
      this.show = !this.show;
    })
  }

  editUserInfo(uid:any){
    // read to update
    this.us.getUserToEdit(uid).subscribe( res => {
      this.euser = res;
      this.show = !this.show;
    } );
  }
  deleteUserInfo(uid:any){
    // delete
    this.us.deleteUser(uid).subscribe( res => {
      console.log( res );
      this.refresh();
    })
  }
}
