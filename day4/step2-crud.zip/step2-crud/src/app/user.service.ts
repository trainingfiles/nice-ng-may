import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";

@Injectable()
export class UserService{
    serverurl = "http://localhost:5050";
    constructor(private http:HttpClient){}

    //READ
    getUserData(){
        return this.http.get(this.serverurl+"/data");
    }
    //CREATE
    postUserData(nuser:any){
        return this.http.post(this.serverurl+"/data", nuser);
    }
    //READ TO UPDATE
    getUserToEdit(uid:any){
        return this.http.get(this.serverurl+"/user/"+uid);
    }
    //UPDATE
    postUserAfterUpdate(user:any){
        return this.http.put(this.serverurl+"/user/"+user._id, user);
    }
    //DELETE
    deleteUser(uid:any){
        return this.http.delete(this.serverurl+"/delete/"+uid);
    }
}