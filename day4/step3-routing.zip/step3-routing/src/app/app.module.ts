import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppComponent } from './app.component';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './home.component';
import { BatmanComponent } from './batman.component';
import { SupermanComponent } from './superman.component';
import { AquamanComponent } from './aquaman.component';
import { NotfoundComponent } from './notfound.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [ 
    AppComponent, 
    HomeComponent,
    BatmanComponent,
    SupermanComponent,
    AquamanComponent,
    NotfoundComponent  ],
  imports: [BrowserModule, FormsModule, RouterModule.forRoot([
      { path : "", component : HomeComponent },/* default route */
      { path : "batman", component : BatmanComponent }, /* named route */
      { path : "superman", component : SupermanComponent },/* named route */
      { path : "aquaman/:qty", component : AquamanComponent },/* route with params */
      { path : "aquaman", component : AquamanComponent }, /* named route */
      { path : "flash", redirectTo : "batman"  }, /* redirection route */
      { path : "**", component : NotfoundComponent }, /* wildcard route */
    ])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
