import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  template: `
    <h2> Aquaman works! </h2>
    <h3>Quantity is : {{ compQuantity }}</h3>
  `,
  styles: [
  ]
})
export class AquamanComponent implements OnInit {
  compQuantity:any = 0;
  constructor(private ar:ActivatedRoute) { }

  ngOnInit(): void {
    this.compQuantity = this.ar.snapshot.params['qty'];
  }

}
