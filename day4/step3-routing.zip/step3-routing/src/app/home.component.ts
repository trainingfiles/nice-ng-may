import { Component, OnInit } from '@angular/core';

@Component({
  template: `
    <h2> Home Component </h2>
  `,
})
export class HomeComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
